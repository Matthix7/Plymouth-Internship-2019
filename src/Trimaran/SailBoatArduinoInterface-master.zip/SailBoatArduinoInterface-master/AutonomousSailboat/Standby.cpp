#include "Standby.h"
#include <Sailboat.h>

Standby::Standby(){
}
void Standby::init() {
}
void Standby::Control(const geometry_msgs::Twist& cmd) {
}
